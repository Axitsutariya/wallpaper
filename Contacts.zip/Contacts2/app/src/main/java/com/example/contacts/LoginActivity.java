package com.example.contacts;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.permissionx.guolindev.PermissionX;
import com.permissionx.guolindev.callback.RequestCallback;

import java.util.List;


public class LoginActivity extends AppCompatActivity {

    EditText etuser, etpassword;

    TextView signup, forgotpassword;

    CheckBox cb;
    Button login;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();


        etuser = findViewById(R.id.etuser);
        etpassword = findViewById(R.id.etpassword);
        login = findViewById(R.id.login);
        signup = findViewById(R.id.signup);
        cb = findViewById(R.id.cb);
        forgotpassword = findViewById(R.id.forgotpassword);


        cb.setChecked(App.getstatus());

        if (App.getstatus()) {
            etuser.setText(App.getuser());
            etpassword.setText(App.getpassword());
        }

        if (!App.getUID().equals("")) {
            Intent intent = new Intent(LoginActivity.this, ContactMain.class);
            startActivity(intent);
            finish();
        }

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String user = etuser.getText().toString().trim();
                String password = etpassword.getText().toString().trim();


                if (cb.isChecked()) {
                    App.setstatus(true);
                    App.setuser(user);
                    App.setpassword(password);
                } else {
                    App.setstatus(false);
                }


                if (user.equals("")) {
                    etuser.setError("plz fill");
                    Toast.makeText(LoginActivity.this, "fill email/number", Toast.LENGTH_SHORT).show();

                } else if (password.equals("")) {
                    etpassword.setError("plz fill");
                    Toast.makeText(LoginActivity.this, "fill password", Toast.LENGTH_SHORT).show();


                } else {
                    Log.d("TAG", "data 1: " + user);
                    Log.d("TAG", "data 2: " + password);

                    Cursor cursor = App.db.rawQuery("select * from reg where email='" + user + "' and pass='" + password + "'", null);

                    if (cursor != null) {


                        if (cursor.moveToNext()) {

                            String id = cursor.getString(0);
                            String path = cursor.getString(1);
                            String username = cursor.getString(2);
                            String number = cursor.getString(3);
                            String email = cursor.getString(4);
                            String bod = cursor.getString(5);
                            String gender = cursor.getString(6);
                            String address = cursor.getString(7);
                            String city = cursor.getString(8);
                            String pass = cursor.getString(9);

                            Log.d("TAG", "data 1: " + id);
                            Log.d("TAG", "data 1: " + path);
                            Log.d("TAG", "data 1: " + username);
                            Log.d("TAG", "data 1: " + number);
                            Log.d("TAG", "data 1: " + email);
                            Log.d("TAG", "data 1: " + bod);
                            Log.d("TAG", "data 1: " + gender);
                            Log.d("TAG", "data 1: " + address);
                            Log.d("TAG", "data 1: " + city);
                            Log.d("TAG", "data 1: " + pass);

                            App.setUID(id);

                            Toast.makeText(LoginActivity.this, "valid", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, ContactMain.class);
                            startActivity(intent);
                            finish();

                        } else {
                            Toast.makeText(LoginActivity.this, "not valid", Toast.LENGTH_SHORT).show();

                        }


                    }


//                    Cursor cursor = App.db.rawQuery("select * from reg", null);
//
//                    if (cursor != null) {
//
//
//                        if (cursor.moveToNext()) {
//
//
//
//                            String email=cursor.getString(4);
//                            String pass=cursor.getString(9);
//
//                            Toast.makeText(LoginActivity.this, ""+email, Toast.LENGTH_SHORT).show();
//                            Toast.makeText(LoginActivity.this, ""+pass, Toast.LENGTH_SHORT).show();
//                            Log.d("tag", "onClick: "+email);
//                            Log.d("tag", "onClick: "+pass);
//
//                        }
//                    }


//                    finish();

                }


            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });

        forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                Intent intent = new Intent(LoginActivity.this, ForgotActivity.class);
//                startActivity(intent);

                showfpdialog();


//                    Cursor cursor = App.db.rawQuery("select * from reg", null);
//
//                    if (cursor != null) {
//
//
//                        if (cursor.moveToNext()) {
//
//
//
//                            String email=cursor.getString(4);
//                            String pass=cursor.getString(9);
//
//                            Toast.makeText(LoginActivity.this, ""+email, Toast.LENGTH_SHORT).show();
//                            Toast.makeText(LoginActivity.this, ""+pass, Toast.LENGTH_SHORT).show();
//
//                            Log.d("tag", "onClick: "+email);
//                            Log.d("tag", "onClick: "+pass);
//
//                        }
//                    }

            }
        });

    }

    public void showfpdialog() {


        Dialog dialog = new Dialog(LoginActivity.this, android.R.style.Theme_Material_Light_Dialog_Alert);
        dialog.setContentView(R.layout.dialog_forgot_password);
        dialog.setTitle("Forgot password");
        dialog.setCancelable(true);

        EditText et = dialog.findViewById(R.id.et);
        Button btn = dialog.findViewById(R.id.btn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String data = et.getText().toString().trim();


                if (data.equals("")) {
                    Toast.makeText(LoginActivity.this, "plz fill", Toast.LENGTH_SHORT).show();
                    return;
                }
                Cursor cursor = App.db.rawQuery("select * from reg where email='" + data + "'", null);
                if (cursor != null) {


                    if (cursor.moveToNext()) {
                        String number = cursor.getString(3);
                        String pass = cursor.getString(9);

                        try {
                            String msg="your password"  + pass;
                            SmsManager smsManager=SmsManager.getDefault();
                            smsManager.sendTextMessage(number,"",msg,null,null);

                            Toast.makeText(LoginActivity.this, "successfully send sms", Toast.LENGTH_SHORT).show();

                        }catch (Exception e){
                            Toast.makeText(LoginActivity.this, "plz allow permission", Toast.LENGTH_SHORT).show();
                        }

//                        Toast.makeText(LoginActivity.this, "" + number, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginActivity.this, "not found", Toast.LENGTH_SHORT).show();
                    }
                }

                dialog.dismiss();
            }
        });

        dialog.show();


    }

    public void mypermission(){

        PermissionX.init(this)
                .permissions(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.SEND_SMS, Manifest.permission.CALL_PHONE)

                .request(new RequestCallback() {
                    @Override
                    public void onResult(boolean allGranted, @NonNull List<String> grantedList, @NonNull List<String> deniedList) {

                    }
                });
    }

}

