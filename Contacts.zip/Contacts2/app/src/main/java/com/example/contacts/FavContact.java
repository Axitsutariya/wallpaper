package com.example.contacts;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.github.dhaval2404.imagepicker.ImagePicker;

import java.util.ArrayList;
import java.util.Collections;

import de.hdodenhof.circleimageview.CircleImageView;

public class FavContact extends AppCompatActivity implements ContactAdapter.Myclick {


    RecyclerView favrv;



    ArrayList<ContactItem> listitem = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fav_main);

        favrv=findViewById(R.id.favrv);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        favrv.setLayoutManager(linearLayoutManager);

        dataload();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        dataload();
    }

    public void dataload() {

        listitem.clear();
        Cursor cursor = App.db.rawQuery("select * from fav", null);
        if (cursor != null) {

            while (cursor.moveToNext()) {

                String id = cursor.getString(0);
                String cid = cursor.getString(1);
                String uid = cursor.getString(2);

                if (mycon(cid) != null) {
                    listitem.add(mycon(cid));
                }



            }


            ContactAdapter contactAdapter = new ContactAdapter(listitem, FavContact.this, FavContact.this);
            favrv.setAdapter(contactAdapter);
        }
    }

    public ContactItem mycon(String cid){

        ContactItem contactItem=null;

        Cursor cursor = App.db.rawQuery("select * from con where id='" + cid+ "'", null);
        if (cursor != null) {

            if (cursor.moveToNext()) {

                String id = cursor.getString(0);
                String path = cursor.getString(1);
                String fname = cursor.getString(2);
                String lname = cursor.getString(3);
                String number = cursor.getString(4);
                String address = cursor.getString(5);
                String bod = cursor.getString(6);
                String uid = cursor.getString(7);

                contactItem=new ContactItem(id,path,fname,lname,number,address,bod,uid);

            }

        }

        return contactItem;
    }



    @Override
    public void ll_click(int pos) {
    }

    @Override
    public void add(int pos) {}

    @Override
    public void more(int pos, View view) {

        App.db.execSQL("delete from fav where cid='"+listitem.get(pos).getId()+"'");
        dataload();

        Toast.makeText(FavContact.this, "Unfavorite" , Toast.LENGTH_SHORT).show();

    }
}
