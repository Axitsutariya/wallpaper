package com.example.contacts;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.github.dhaval2404.imagepicker.ImagePicker;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;

public class SignupActivity extends Activity {


    String username, number, email, bod, address, creatpassword, confirmpassword;
    EditText etusername, etnumber, etemail, etbod, etaddress, etcreatpassword, etconfirmpassword;
    Button signup;
    ImageView date;
    int y, m, d;
    RadioButton r1;
    RadioButton r2;

    String city = "";
    String gender = "";
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    String path = "";
    CircleImageView siv;

    Spinner sp;
    ArrayList<CityItem> listItems = new ArrayList<>();
    Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etusername = findViewById(R.id.etusername);

        etemail = findViewById(R.id.etemail);
        etnumber = findViewById(R.id.etnumber);
        etcreatpassword = findViewById(R.id.etcreatpassword);
        etconfirmpassword = findViewById(R.id.etconfirmpassword);
        etbod = findViewById(R.id.etbod);
        etaddress = findViewById(R.id.etaddress);
        signup = findViewById(R.id.signup);
        date = findViewById(R.id.date);
        r1 = findViewById(R.id.r1);
        r2 = findViewById(R.id.r2);
        sp = findViewById(R.id.sp);
        siv = findViewById(R.id.siv);


        listItems.add(new CityItem("Select city"));
        listItems.add(new CityItem("Surat"));
        listItems.add(new CityItem("Vadora"));
        listItems.add(new CityItem("Bhavanagr"));
        listItems.add(new CityItem("Rajkot"));
        listItems.add(new CityItem("Porbandar"));
        listItems.add(new CityItem("Gondal"));
        listItems.add(new CityItem("Vapi"));
        listItems.add(new CityItem("Veraval"));
        listItems.add(new CityItem("Godhra"));
        listItems.add(new CityItem("Jetpur"));
        listItems.add(new CityItem("Botad"));
        listItems.add(new CityItem("Dahod"));
        listItems.add(new CityItem("Deesa"));
        listItems.add(new CityItem("Amreli"));


        CityAdapter cityAdapter = new CityAdapter(listItems, SignupActivity.this);

        sp.setAdapter(cityAdapter);


        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                city = listItems.get(i).getName();

                if (city.equalsIgnoreCase("Select city")) {
                    return;
                }

                Toast.makeText(SignupActivity.this, "" + city, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                username = etusername.getText().toString().trim();
                number = etnumber.getText().toString().trim();
                email = etemail.getText().toString().trim();
                bod = etbod.getText().toString().trim();
                address = etaddress.getText().toString().trim();
                creatpassword = etcreatpassword.getText().toString().trim();
                confirmpassword = etconfirmpassword.getText().toString().trim();

                if (r1.isChecked()) {
                    gender = "male";
                } else {
                    gender = "female";
                }


                if (path.equals("")) {
                    Toast.makeText(SignupActivity.this, "select profile pic", Toast.LENGTH_SHORT).show();

                } else if (username.equals("")) {
                    etusername.setError("plz fill");
                    Toast.makeText(SignupActivity.this, "fill username", Toast.LENGTH_SHORT).show();

                } else if (number.equals("")) {
                    etnumber.setError("plz fill");
                    Toast.makeText(SignupActivity.this, "fill number", Toast.LENGTH_SHORT).show();


                } else if (email.equals("")) {
                    etemail.setError("plz fill");
                    Toast.makeText(SignupActivity.this, "fill email", Toast.LENGTH_SHORT).show();

                } else if (!email.matches(emailPattern)) {
                    Toast.makeText(SignupActivity.this, "fill email", Toast.LENGTH_SHORT).show();

                } else if (bod.equals("")) {
                    etbod.setError("plz fill");
                    Toast.makeText(SignupActivity.this, "fill bod", Toast.LENGTH_SHORT).show();

                } else if (gender.equals("")) {
                    Toast.makeText(SignupActivity.this, "fill gender", Toast.LENGTH_SHORT).show();

                } else if (address.equals("")) {
                    etaddress.setError("plz fill");
                    Toast.makeText(SignupActivity.this, "fill address", Toast.LENGTH_SHORT).show();

                } else if (city.equals("")) {
                    Toast.makeText(SignupActivity.this, "fill city", Toast.LENGTH_SHORT).show();

                } else if (creatpassword.equals("")) {
                    etcreatpassword.setError("plz fill");
                    Toast.makeText(SignupActivity.this, "fill creatpassword", Toast.LENGTH_SHORT).show();

                } else if (confirmpassword.equals("")) {
                    etconfirmpassword.setError("plz fill");
                    Toast.makeText(SignupActivity.this, "fill confirmpassword", Toast.LENGTH_SHORT).show();

                } else if (!confirmpassword.equals(creatpassword)) {
                    Toast.makeText(SignupActivity.this, "fill both password same", Toast.LENGTH_SHORT).show();

                } else {


                    Log.d("ok", "Data 0: " + path);
                    Log.d("ok", "Data 1: " + username);
                    Log.d("ok", "Data 2: " + number);
                    Log.d("ok", "Data 3: " + email);
                    Log.d("ok", "Data 4: " + bod);
                    Log.d("ok", "Data 4: " + gender);
                    Log.d("ok", "Data 5: " + address);
                    Log.d("ok", "Data 5: " + city);
                    Log.d("ok", "Data 6: " + creatpassword);
                    Log.d("ok", "Data 7: " + confirmpassword);


                    Cursor cursor = App.db.rawQuery("select * from reg where email='" + email + "'", null);

                    if (cursor != null) {


                        if (cursor.moveToNext()) {

                            Toast.makeText(SignupActivity.this, "already, you need login", Toast.LENGTH_SHORT).show();
                        } else {
                            App.db.execSQL("insert into reg(path ,username ,number ,email ,bod ,gender ,address ,city ,pass ) values('" + path + "','" + username + "','" + number + "','" + email + "','" + bod + "','" + gender + "','" + address + "','" + city + "','" + creatpassword + "')");

                            Toast.makeText(SignupActivity.this, "done", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }

                }

//
//                Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
//                startActivity(intent);


            }

        });

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                y = calendar.get(Calendar.YEAR);
                m = calendar.get(Calendar.MONTH);
                d = calendar.get(Calendar.DAY_OF_MONTH);

                Log.d("TAG", "onClick: " + d + "/" + (m + 1) + "/" + y);


                DatePickerDialog datePickerDialog = new DatePickerDialog(SignupActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int y, int m, int d) {

                        Log.d("TAG", "onClick: " + d + "/" + (m + 1) + "/" + (y - 1));

                        etbod.setText(d + "/" + (m + 1) + "/" + y);
                    }

                }, y, m, d);

                datePickerDialog.show();

            }
        });


        siv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.with(SignupActivity.this)
                        .crop()                    //Crop image(Optional), Check Customization for more option
                        .compress(1024)            //Final image size will be less than 1 MB(Optional)
                        .maxResultSize(1080, 1080)    //Final image resolution will be less than 1080 x 1080(Optional)
                        .start();
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {


        if (resultCode == RESULT_OK) {

            Uri uri = data.getData();

            path = uri.getPath();
            Glide.with(this).load(uri).into(siv);

        } else {
            Toast.makeText(this, "cancel", Toast.LENGTH_SHORT).show();
        }
        super.onActivityResult(requestCode, resultCode, data);

    }
}