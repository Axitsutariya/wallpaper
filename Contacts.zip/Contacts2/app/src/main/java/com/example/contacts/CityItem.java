package com.example.contacts;

public class CityItem {
    String name;

    public CityItem(String name) {
        this.name = name;
    }

    public static CityItem get(int i) {
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
