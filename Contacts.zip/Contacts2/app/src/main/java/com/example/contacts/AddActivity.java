package com.example.contacts;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.github.dhaval2404.imagepicker.ImagePicker;

import java.time.Instant;
import java.time.temporal.TemporalAdjuster;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;

public class AddActivity extends Activity {


    String path = "";
    CircleImageView aiv;
    Button savecontact;
    EditText fname, lname, addnumber, addaddress, addbirthdate;
    String name, name2, number, address, birthdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contacts);


        aiv = findViewById(R.id.aiv);
        savecontact = findViewById(R.id.savecontact);
        fname = findViewById(R.id.fname);
        lname = findViewById(R.id.lname);
        addnumber = findViewById(R.id.addnumber);
        addaddress = findViewById(R.id.addaddress);
        addbirthdate = findViewById(R.id.addbirthdate);


        savecontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                name = fname.getText().toString().trim();
                name2 = lname.getText().toString().trim();
                number = addnumber.getText().toString().trim();
                address = addaddress.getText().toString().trim();
                birthdate = addbirthdate.getText().toString().trim();


                if (path.equals("")) {
                    Toast.makeText(AddActivity.this, "select profile pic", Toast.LENGTH_SHORT).show();

                } else if (name.equals("")) {
                    fname.setError("plzz fill");
                    Toast.makeText(AddActivity.this, "fill firstname", Toast.LENGTH_SHORT).show();

                } else if (name2.equals("")) {
                    lname.setError("plzz fill");
                    Toast.makeText(AddActivity.this, "fill lastname", Toast.LENGTH_SHORT).show();

                } else if (number.equals("")) {
                    addnumber.setError("plzz fill");
                    Toast.makeText(AddActivity.this, "fill number", Toast.LENGTH_SHORT).show();

                } else if (address.equals("")) {
                    addaddress.setError("plzz fill");
                    Toast.makeText(AddActivity.this, "fill address", Toast.LENGTH_SHORT).show();

                } else if (birthdate.equals("")) {
                    addbirthdate.setError("plzz fill");
                    Toast.makeText(AddActivity.this, "fill birthdate", Toast.LENGTH_SHORT).show();

                } else {

                    Log.d("TAG", "onClick: " + path);
                    Log.d("TAG", "onClick: " + name);
                    Log.d("TAG", "onClick: " + name2);
                    Log.d("TAG", "onClick: " + number);
                    Log.d("TAG", "onClick: " + address);
                    Log.d("TAG", "onClick: " + birthdate);

                    Cursor cursor = App.db.rawQuery("select * from con where number='" + number + "' and uid='" + App.getUID() + "'", null);

                    if (cursor != null) {

                        if (cursor.moveToNext()) {

                            Toast.makeText(AddActivity.this, "already,add conatct", Toast.LENGTH_SHORT).show();
                        } else {
                            App.db.execSQL("insert into con(path ,fname ,lname ,number ,address ,bod,uid ) values('" + path + "','" + name + "','" + name2 + "','" + number + "','" + address + "','" + birthdate + "','" + App.getUID() + "')");

                            Toast.makeText(AddActivity.this, "Save ", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                }
            }
        });

        aiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.with(AddActivity.this)
                        .crop()                    //Crop image(Optional), Check Customization for more option
                        .compress(1024)            //Final image size will be less than 1 MB(Optional)
                        .maxResultSize(1080, 1080)    //Final image resolution will be less than 1080 x 1080(Optional)
                        .start();
            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {


        if (resultCode == RESULT_OK) {

            Uri uri = data.getData();

            path = uri.getPath();
            Glide.with(this).load(uri).into(aiv);

        } else {
            Toast.makeText(this, "cancel", Toast.LENGTH_SHORT).show();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
