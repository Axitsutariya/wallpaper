package com.example.contacts;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Locale;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.Myh> {


    ArrayList<ContactItem> contactItems;
    ArrayList<ContactItem> temcontactItems;
    Context context;
    Myclick myclick;

    public ContactAdapter(ArrayList<ContactItem> contactItems, Context context, Myclick myclick) {
        this.contactItems = contactItems;
        this.context = context;
        this.myclick = myclick;
      temcontactItems=new ArrayList<>();
      temcontactItems.addAll(contactItems);
    }

    @NonNull
    @Override
    public Myh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_contact, parent, false);
        return new Myh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Myh holder, int position) {
        holder.tv.setText(contactItems.get(position).getFname());
        holder.tv2.setText(contactItems.get(position).getNumber());
        Glide.with(context).load(contactItems.get(position).getPath()).into(holder.iv);


        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myclick.ll_click(position);
            }
        });


        holder.more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myclick.more(position, view);
            }
        });


    }

    @Override
    public int getItemCount() {
        return contactItems.size();
    }

    public class Myh extends RecyclerView.ViewHolder {

        LinearLayout linearLayout;
        TextView tv,tv2;
        ImageView more;
        ImageView iv;


        public Myh(@NonNull View itemView) {
            super(itemView);

            tv = itemView.findViewById(R.id.tv);
            linearLayout = itemView.findViewById(R.id.linearLayout);
            tv2 = itemView.findViewById(R.id.tv2);
            more = itemView.findViewById(R.id.more);
            iv = itemView.findViewById(R.id.iv);

        }
    }

    public interface Myclick {

        public void ll_click(int pos);

        public void add(int pos);

        public void more(int pos, View view);
    }

    public void filter(String query){

        query=query.toLowerCase(Locale.ROOT);
      contactItems.clear();

        if (query.length()== 0) {
            contactItems.addAll(temcontactItems);

        }else{
            for (ContactItem temcontactItem : temcontactItems){

                if (temcontactItem.getNumber().toLowerCase(Locale.ROOT).contains(query)) {
                    contactItems.add(temcontactItem);
                }else if (temcontactItem.getFname().toLowerCase(Locale.ROOT).contains(query)) {
                    contactItems.add(temcontactItem);
                }else if (temcontactItem.getLname().toLowerCase(Locale.ROOT).contains(query)) {
                    contactItems.add(temcontactItem);
                }
            }
        }

        notifyDataSetChanged();
    }
}
