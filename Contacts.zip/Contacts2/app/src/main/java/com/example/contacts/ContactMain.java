package com.example.contacts;

import android.app.Dialog;
import android.app.SearchManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.PopupMenu;

import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;

import de.hdodenhof.circleimageview.CircleImageView;

public class ContactMain extends AppCompatActivity implements ContactAdapter.Myclick {

    RecyclerView rv;
    CircleImageView editiv;
    FloatingActionButton add;
    ArrayList<ContactItem> contactItems = new ArrayList<>();

    EditText editfname,editlname,editphonenumber,updateaddress,updatebod;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_main);

        rv = findViewById(R.id.lv);
        add = findViewById(R.id.add);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(linearLayoutManager);


        dataload();

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ContactMain.this, AddActivity.class);
                startActivity(intent);
            }
        });


    }

    @Override
    protected void onRestart() {
        super.onRestart();
        dataload();
    }

    public void dataload() {

        contactItems.clear();
        Cursor cursor = App.db.rawQuery("select * from con where uid='" + App.getUID() + "'", null);
        if (cursor != null) {

            while (cursor.moveToNext()) {

                String id = cursor.getString(0);
                String path = cursor.getString(1);
                String fname = cursor.getString(2);
                String lname = cursor.getString(3);
                String number = cursor.getString(4);
                String address = cursor.getString(5);
                String bod = cursor.getString(6);
                String uid = cursor.getString(7);

                contactItems.add(new ContactItem(id, path, fname, lname, number, address, bod, uid));
            }

            Collections.reverse(contactItems);
             contactAdapter = new ContactAdapter(contactItems, ContactMain.this, ContactMain.this);
            rv.setAdapter(contactAdapter);
        }
    }

    ContactAdapter contactAdapter;


    @Override
    public void ll_click(int pos) {
        String name = contactItems.get(pos).getFname();
//        Toast.makeText(this, "" + name, Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:"+contactItems.get(pos).getNumber()));
        startActivity(intent);
//        Intent intent = new Intent(ContactMain.this, UpdateContact.class);
//        startActivity(intent);
    }

    @Override
    public void add(int pos) {
        Intent intent = new Intent(ContactMain.this, AddActivity.class);
        startActivity(intent);
    }

    @Override
    public void more(int pos, View view) {

//        showcmdialog();

        PopupMenu popupMenu = new PopupMenu(ContactMain.this, view);
        popupMenu.getMenuInflater().inflate(R.menu.contact_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.et) {
                    Toast.makeText(ContactMain.this, "" + contactItems.get(pos).getId(), Toast.LENGTH_SHORT).show();

                    App.setcid(contactItems.get(pos).getId());

                    Intent intent = new Intent(ContactMain.this, UpdateContact.class);
                    startActivity(intent);
                }

                if (menuItem.getItemId() == R.id.delete) {

                    App.db.execSQL("delete from con where id='"+contactItems.get(pos).getId()+"'");
                    dataload();

                    Toast.makeText(ContactMain.this, "Delete" , Toast.LENGTH_SHORT).show();
                }
                if (menuItem.getItemId() == R.id.sharecontact) {

                    String msg = contactItems.get(pos).getNumber()+""+contactItems.get(pos).getFname();
                    Intent sendintent=new Intent();
                    sendintent.setAction(Intent.ACTION_SEND);
                    sendintent.putExtra(Intent.EXTRA_TEXT,msg);
                    sendintent.setType("text/plain");

                    Intent shareintent=Intent.createChooser(sendintent,null);
                    startActivity(shareintent);
                }

                if (menuItem.getItemId() == R.id.copy) {
                    String data=contactItems.get(pos).getNumber();

                    ClipboardManager clipboardManager=(ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip=ClipData.newPlainText("lable",data);
                    clipboardManager.setPrimaryClip(clip);
                    Toast.makeText(ContactMain.this, "Copy", Toast.LENGTH_SHORT).show();
                }

                if (menuItem.getItemId() == R.id.fav) {
                   Cursor cursor= App.db.rawQuery("select * from fav where cid='"+contactItems.get(pos).getId()+"'" ,null);

                    if (cursor !=null) {

                        if (cursor.moveToNext()) {

                            App.db.execSQL("delete from fav where cid = ' "+ contactItems.get(pos).getId()+"'");
                            Toast.makeText(ContactMain.this, "favorite removed", Toast.LENGTH_SHORT).show();
                        }else {

                            Toast.makeText(ContactMain.this, "favorite added", Toast.LENGTH_SHORT).show();

                            App.db.execSQL("insert into fav(cid,uid)values('"+ contactItems.get(pos).getId()+"','"+App.getUID()+"')");

                        }

                    }

                }
                return false;
            }
        });

        popupMenu.show();


    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.home_menu, menu);

        SearchManager manager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);


        SearchView search = (SearchView) menu.findItem(R.id.search_bar).getActionView();

        search.setSearchableInfo(manager.getSearchableInfo(getComponentName()));

        search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
//                    Toast.makeText(FirstMainActivity.this, "" + query, Toast.LENGTH_SHORT).show();

                Log.d("TAG", "onQueryTextSubmit: "+query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {


                Log.d("TAG", "onQueryTextChange: "+newText);

                contactAdapter.filter(newText);
                contactAdapter.notifyDataSetChanged();
                return false;

            }

        });

        return super.onCreateOptionsMenu(menu);

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {


        if (item.getItemId() == R.id.share) {
            Toast.makeText(this, "share", Toast.LENGTH_SHORT).show();
            String msg ="https://play.google.com/store/apps/details?id="+getPackageName();
            Intent sendintent=new Intent();
            sendintent.setAction(Intent.ACTION_SEND);
            sendintent.putExtra(Intent.EXTRA_TEXT,msg);
            sendintent.setType("text/plain");

            Intent shareintent=Intent.createChooser(sendintent,null);
            startActivity(shareintent);

        }
        if (item.getItemId() == R.id.editprofile) {



            Intent intent = new Intent(ContactMain.this, EditActivity.class);
            startActivity(intent);


        }
        if (item.getItemId() == R.id.sfav) {
            Intent intent = new Intent(ContactMain.this, FavContact.class);
            startActivity(intent);
        }
        if (item.getItemId() == R.id.cp) {
            Intent intent = new Intent(ContactMain.this, ChangPassword.class);
            startActivity(intent);
        }
        if (item.getItemId() == R.id.logout) {
            Toast.makeText(this, "logout", Toast.LENGTH_SHORT).show();
            App.setUID("");
            Intent intent=new Intent(ContactMain.this,LoginActivity.class);
            startActivity(intent);
            finish();
        }


        return super.onOptionsItemSelected(item);
    }

//    public void showcpdialog() {
//
//
//        Dialog dialog = new Dialog(ContactMain.this, android.R.style.Theme_Material_Light_Dialog);
//        dialog.setContentView(R.layout.dialog_change_password);
//        dialog.setTitle("Chang Password");
//        dialog.setCancelable(true);
//
//        dialog.show();
//    }


    public void exitdilaog() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage("are you want to exit app....");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    @Override
    public void onBackPressed() {
        exitdilaog();
    }
}
