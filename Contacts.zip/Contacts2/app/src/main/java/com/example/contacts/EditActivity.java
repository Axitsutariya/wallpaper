package com.example.contacts;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.github.dhaval2404.imagepicker.ImagePicker;

import java.util.Calendar;

import de.hdodenhof.circleimageview.CircleImageView;

public class EditActivity extends Activity {

    String path = "";
    CircleImageView eiv;
    ImageView editdateimage;
    EditText editname, editnumber, editemail, editbod, editaddress;
    String editgender = "";
    Button savecontact;

    String fname,lname,phone,address,bod;

    int y, m, d;

    Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);


        eiv = findViewById(R.id.eiv);
        editname = findViewById(R.id.editname);
        editnumber = findViewById(R.id.editnumber);
        savecontact = findViewById(R.id.savecontact);
        editbod = findViewById(R.id.editbod);
        editaddress = findViewById(R.id.editaddress);
        editdateimage = findViewById(R.id.editdateimage);


        dataload();

        savecontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fname=editname.getText().toString();
                phone=editnumber.getText().toString();
                address=editaddress.getText().toString();
                bod=editbod.getText().toString();

                App.db.execSQL("update con set path='"+path+"',fname='"+fname+"',number='"+phone+"',address='"+address+"',bod='"+bod+"'where id='"+App.getcid()+"'    ");
                finish();
            }
        });




        eiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.with(EditActivity.this)
                        .crop()                    //Crop image(Optional), Check Customization for more option
                        .compress(1024)            //Final image size will be less than 1 MB(Optional)
                        .maxResultSize(1080, 1080)    //Final image resolution will be less than 1080 x 1080(Optional)
                        .start();
            }
        });


        editdateimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                y = calendar.get(Calendar.YEAR);
                m = calendar.get(Calendar.MONTH);
                d = calendar.get(Calendar.DAY_OF_MONTH);

                Log.d("TAG", "onClick: " + d + "/" + (m + 1) + "/" + y);


                DatePickerDialog datePickerDialog = new DatePickerDialog(EditActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int y, int m, int d) {

                        Log.d("TAG", "onClick: " + d + "/" + (m + 1) + "/" + (y - 1));

                        editbod.setText(d + "/" + (m + 1) + "/" + y);
                    }

                }, y, m, d);

                datePickerDialog.show();

            }
        });

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        dataload();
    }

    public void dataload() {

        Cursor cursor = App.db.rawQuery("select * from reg where id='" + App.getUID() + "'", null);
        if (cursor != null) {


            if (cursor.moveToNext()) {

                String id = cursor.getString(0);
                path = cursor.getString(1);
                String username = cursor.getString(2);
                String number = cursor.getString(3);
                String bod = cursor.getString(5);
                String address = cursor.getString(7);



                editname.setText(username);
                editnumber.setText(number);
                editbod.setText(bod);
                editaddress.setText(address);


                Glide.with(this).load(path).into(eiv);

            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {


        if (resultCode == RESULT_OK) {

            Uri uri = data.getData();

            path = uri.getPath();
            Glide.with(this).load(uri).into(eiv);

        } else {
            Toast.makeText(this, "cancel", Toast.LENGTH_SHORT).show();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

}
