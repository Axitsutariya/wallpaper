package com.example.contacts;

public class ContactItem {


    String id;
    String path;
    String fname;
    String lname;
    String number;
    String address;
    String bod;
    String uid;


    public ContactItem(String id, String path, String fname, String lname, String number, String address, String bod, String uid) {
        this.id = id;
        this.path = path;
        this.fname = fname;
        this.lname = lname;
        this.number = number;
        this.address = address;
        this.bod = bod;
        this.uid = uid;
    }



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBod() {
        return bod;
    }

    public void setBod(String bod) {
        this.bod = bod;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
