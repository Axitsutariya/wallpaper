package com.example.contacts;

import android.app.Application;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

public class App extends Application {

    static SharedPreferences sharedPreferences;
    static SharedPreferences.Editor editor;

    static SQLiteDatabase db;

    @Override
    public void onCreate() {
        super.onCreate();

        sharedPreferences = getSharedPreferences("contact", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        db = openOrCreateDatabase("my.db", MODE_PRIVATE, null);
        db.execSQL("create table if not exists reg(id integer primary key autoincrement,path text,username text,number text,email text,bod text,gender text,address text,city text,pass text)");
        db.execSQL("create table if not exists con(id integer primary key autoincrement,path text, fname text,lname text,number text, address text, bod text,uid text)");
        db.execSQL("create table if not exists fav(id integer primary key autoincrement,cid text, uid text)");
    }

    public static void setstatus(boolean status) {
        editor.putBoolean("status", status).commit();
    }

    public static boolean getstatus() {
        return sharedPreferences.getBoolean("status", false);
    }


    public static void setuser(String id) {
        editor.putString("id", id).commit();
    }

    public static String getuser() {
        return sharedPreferences.getString("id", "");
    }


    public static void setUID(String UID) {
        editor.putString("UID", UID).commit();
    }

    public static String getUID() {
        return sharedPreferences.getString("UID", "");
    }


    public static void setcid(String cid) {
        editor.putString("cid", cid).commit();
    }

    public static String getcid() {
        return sharedPreferences.getString("cid", "");
    }


    public static void setpassword(String password) {
        editor.putString("password", password).commit();
    }

    public static String getpassword() {
        return sharedPreferences.getString("password", "");
    }
}
