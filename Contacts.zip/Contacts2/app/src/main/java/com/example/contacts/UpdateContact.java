package com.example.contacts;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.github.dhaval2404.imagepicker.ImagePicker;

import java.util.ArrayList;
import java.util.Collections;

import de.hdodenhof.circleimageview.CircleImageView;

public class UpdateContact extends Activity {

    CircleImageView editiv;
    Button upcontact;
    EditText editfname,editlname,editphonenumber,updateaddress,updatebod;
    String fname,lname,phone,address,bod,path;

    ArrayList<ContactItem>contactItems=new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_contact);

        editiv=findViewById(R.id.editiv);
        upcontact=findViewById(R.id.upconatct);
        editfname=findViewById(R.id.editfname);
        editlname=findViewById(R.id.editlname);
        editphonenumber=findViewById(R.id.editphonenumber);
        updateaddress=findViewById(R.id.updateaddress);
        updatebod=findViewById(R.id.updatebod);

        dataload();




        upcontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fname=editfname.getText().toString();
                lname=editlname.getText().toString();
                phone=editphonenumber.getText().toString();
                address=updateaddress.getText().toString();
                bod=updatebod.getText().toString();

                App.db.execSQL("update con set path='"+path+"',fname='"+fname+"',lname='"+lname+"',number='"+phone+"',address='"+address+"',bod='"+bod+"'where id='"+App.getcid()+"'    ");
                finish();
            }
        });

        editiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.with(UpdateContact.this)
                        .crop()                    //Crop image(Optional), Check Customization for more option
                        .compress(1024)            //Final image size will be less than 1 MB(Optional)
                        .maxResultSize(1080, 1080)    //Final image resolution will be less than 1080 x 1080(Optional)
                        .start();
            }
        });
    }



    @Override
    protected void onRestart() {
        super.onRestart();
        dataload();
    }

    public void dataload() {


        Cursor cursor = App.db.rawQuery("select * from con where id='" + App.getcid() + "'", null);
        if (cursor != null) {

            while (cursor.moveToNext()) {

                String id = cursor.getString(0);
                path = cursor.getString(1);
                String fname = cursor.getString(2);
                String lname = cursor.getString(3);
                String number = cursor.getString(4);
                String address = cursor.getString(5);
                String bod = cursor.getString(6);
                String uid = cursor.getString(7);


                editfname.setText(fname);
                editlname.setText(lname);
                editphonenumber.setText(number);
                updateaddress.setText(address);
                updatebod.setText(bod);


                Glide.with(this).load(path).into(editiv);
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {


        if (resultCode == RESULT_OK) {

            Uri uri = data.getData();

            path = uri.getPath();
            Glide.with(this).load(uri).into(editiv);

        } else {
            Toast.makeText(this, "Cancel", Toast.LENGTH_SHORT).show();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
