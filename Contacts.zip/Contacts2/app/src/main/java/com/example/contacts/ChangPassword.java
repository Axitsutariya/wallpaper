package com.example.contacts;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class ChangPassword extends Activity {

    EditText etcp,etnp,etconfirmpassword;
    String cp,np,confirmpass;
    Button spass;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_change_password);

        etcp=findViewById(R.id.cp);
        etnp=findViewById(R.id.np);
        etconfirmpassword=findViewById(R.id.etconfirmpassword);
        spass=findViewById(R.id.spass);


        spass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                cp=etcp.getText().toString();
                np=etnp.getText().toString();
                confirmpass=etconfirmpassword.getText().toString();

                Log.d("TAG", "onClick: "+cp);
                Log.d("TAG", "onClick: "+np);
                Log.d("TAG", "onClick: "+confirmpass);

              Cursor cursor= App.db.rawQuery("select * from reg where pass='"+ cp+"' and id='"+App.getUID()+"'",null);

                if (cursor!=null) {

                    if (cursor.moveToNext()) {

                        App.db.execSQL("update reg set pass = '"+np+"' where id='"+App.getUID()+"'");
                        App.setUID("");
                        Intent intent=new Intent(ChangPassword.this,LoginActivity.class);
                        startActivity(intent);
                        finish();
                        Toast.makeText(ChangPassword.this, "success change password", Toast.LENGTH_SHORT).show();
                    }else {


                        Toast.makeText(ChangPassword.this, "invalid", Toast.LENGTH_SHORT).show();


                    }
                }
            }
        });
    }
}
